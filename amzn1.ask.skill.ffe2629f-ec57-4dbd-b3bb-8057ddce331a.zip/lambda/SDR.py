import json
import ast
import xml.etree.ElementTree as ET
from onem2m import get_data
import datetime
from time import sleep

def latestInstance(server,solar):
    # solar = "/~/in-cse/in-name/AE-SL/SL-VN03-00/Data/la/"
    uriso = server + solar
    returnCode, DescriptorData = get_data(uriso)
    # Handle nan return
    DescriptorData = DescriptorData.replace("nan", "-1.0")
    return ast.literal_eval(DescriptorData)

def getDescriptorInfo(server,solar):
    # solar = "/~/in-cse/in-name/AE-SL/SL-VN03-00/Descriptor/la/"
    uriso = server + solar
    returnCode,DescriptorDataXML = get_data(uriso)
    tree = ET.fromstring(DescriptorDataXML)
    dataDescriptor = {}
    for child in tree:
        # print(f"{child.attrib['name']}:  {child.attrib['val']}")
        dataDescriptor[child.attrib["name"]] = child.attrib["val"]
    dataStringParams = dataDescriptor["Data String Parameters"]
    return ast.literal_eval(dataStringParams)
def getMetaDataSolar():
    server = "https://onem2m.iiit.ac.in:443"
    descriptor_inverter = []
    descriptor_inverter.append("/~/in-cse/in-name/AE-SL/SL-VN03-00/") #80K
    descriptor_inverter.append("/~/in-cse/in-name/AE-SL/SL-VN02-00/") #25K
    descriptor_inverter.append("/~/in-cse/in-name/AE-SL/SL-VN02-01/") #80K
    return server,descriptor_inverter
def getMetaDataWeather():
    server = "https://onem2m.iiit.ac.in:443"
    descriptor_inverter = []
    descriptor_inverter.append("/~/in-cse/in-name/AE-WE/WE-VN04-00/")
    descriptor_inverter.append("/~/in-cse/in-name/AE-WE/WE-BN04-00/")
    return server,descriptor_inverter

    
    
    