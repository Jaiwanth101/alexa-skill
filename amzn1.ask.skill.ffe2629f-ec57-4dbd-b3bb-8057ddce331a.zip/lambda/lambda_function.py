from ask_sdk_core.utils import is_request_type, is_intent_name
from ask_sdk_core.dispatch_components import (AbstractRequestHandler, AbstractExceptionHandler, AbstractRequestInterceptor, AbstractResponseInterceptor)
from ask_sdk_core.skill_builder import CustomSkillBuilder
from ask_sdk_dynamodb.adapter import DynamoDbAdapter

import logging
import json
import random
import os
import boto3

from SDR import latestInstance, getDescriptorInfo,getMetaDataSolar,getMetaDataWeather
import numpy
import ast
import xml.etree.ElementTree as ET
from onem2m import get_data
import datetime


# Defining the database region, table name and dynamodb persistence adapter
ddb_region = os.environ.get('DYNAMODB_PERSISTENCE_REGION')
ddb_table_name = os.environ.get('DYNAMODB_PERSISTENCE_TABLE_NAME')
ddb_resource = boto3.resource('dynamodb', region_name=ddb_region)
dynamodb_adapter = DynamoDbAdapter(table_name=ddb_table_name, create_table=False, dynamodb_resource=ddb_resource)

# Initializing the logger and setting the level to "INFO"
# Read more about it here https://www.loggly.com/ultimate-guide/python-logging-basics/
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Intent Handlers

# This Handler is called when the skill is invoked by using only the invocation name(Ex. Alexa, open template ten)
class LaunchRequestHandler(AbstractRequestHandler):
    
    def can_handle(self, handler_input):
        return is_request_type("LaunchRequest")(handler_input)
    
    def handle(self, handler_input):
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        persistent_attributes = handler_input.attributes_manager.persistent_attributes
        skill_name = language_prompts["SKILL_NAME"]
        
        try:
            # Fetch user's name from the DB.
            user_name = persistent_attributes['user_name']
            speech_output = "Hey "+ user_name+". You can query about your solar panels here. Go ahead and give it a try"
            # speech_output = random.choice(language_prompts["REPEAT_USER_GREETING"]).format(user_name)
            # reprompt = random.choice(language_prompts["REPEAT_USER_GREETING_REPROMPT"])
        except:
            speech_output = random.choice(language_prompts["FIRST_TIME_USER"]).format(skill_name)
            # reprompt = random.choice(language_prompts["FIRST_TIME_USER_REPROMPT"])
        
        return (
            handler_input.response_builder
                .speak(speech_output)
                .ask("")
                .response
            )


class CheckFaultyInverterHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return is_intent_name("CheckFaultyInverter")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        
        server,descriptor_inverter = getMetaDataSolar()
        
        desInfo = getDescriptorInfo(server,descriptor_inverter[0]+"Descriptor/la")
        faultyInverters = []
        indexEGToday = desInfo.index('Energy Generated Today')
        indexPower = desInfo.index('Power')
        
        server_rad, descriptor_inverter_rad = getMetaDataWeather()
        laRad = latestInstance(server,descriptor_inverter_rad[0]+"Data/la")
        solarRadVal = laRad[1]
        
        
        for i in range(3):
            laVal = latestInstance(server,descriptor_inverter[i]+"Data/la")
            del laVal[6]
            laTime = datetime.datetime.fromtimestamp(laVal[0])
            
            if(int(solarRadVal)>100 and int(laVal[indexPower]) == 0):
                faultyInverters.append(i)
        speak_output = ""
        if len(faultyInverters)==0:
            speak_output = "All your panels seem to look good"
            
        else:
            speak_output = "Panels on Inverters : " +str(faultyInverters)+ "seem to be faulty"
            
        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )
class RetrieveLatestInstanceHandler(AbstractRequestHandler):
    """Handler for Hello World Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return is_intent_name("RetrieveLatestInstance")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response

        server,descriptor_inverter = getMetaDataSolar()
        
        
        speak_output = "Latest instance for inverter_0 : \n"
        desInfo = getDescriptorInfo(server,descriptor_inverter[0]+"Descriptor/la")

        laVal = latestInstance(server,descriptor_inverter[0]+"Data/la")
        laVal.pop(6)
        for it in range(8):
            if it == 0:
                laVal[it] = datetime.datetime.fromtimestamp(laVal[it])
            speak_output += desInfo[it] + ":" + str(laVal[it]) + ", "
            
        speak_output += "--------------------------\nLatest instance for inverter_1 : \n"
        laVal = latestInstance(server,descriptor_inverter[1]+"Data/la")
        desInfo1 = getDescriptorInfo(server,descriptor_inverter[1]+"Descriptor/la")
        desInfo1.pop(4)
        desInfo1.pop(4)
        for it in range(5):
            if it == 0:
                laVal[it] = datetime.datetime.fromtimestamp(laVal[it])
            speak_output += desInfo1[it] + ":" + str(laVal[it]) + ", "
        
        
        speak_output += "----------------------------\nLatest instance for inverter_2 : \n"
        desInfo = getDescriptorInfo(server,descriptor_inverter[2]+"Descriptor/la")
        laVal = latestInstance(server,descriptor_inverter[2]+"Data/la")
        laVal.pop(6)
        for it in range(8):
            if it == 0:
                laVal[it] = datetime.datetime.fromtimestamp(laVal[it])
            speak_output += desInfo[it] + ":" + str(laVal[it]) + ", "
        
        

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )
class EnergyGeneratedTodayHandler(AbstractRequestHandler):
    """Handler for Hello World Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return is_intent_name("EnergyGeneratedToday")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        server,descriptor_inverter = getMetaDataSolar()
        
        desInfo = getDescriptorInfo(server,descriptor_inverter[0]+"Descriptor/la")
        # faultyInverters = []
        indexEGToday = desInfo.index('Energy Generated Today')
        indexPower = desInfo.index('Power')
        
        inverterId = 0
        energyTday = 0
        for i in range(3):
            laVal = latestInstance(server,descriptor_inverter[i]+"Data/la")
            energyTday+= laVal[indexEGToday]
        # del laVal[6]
        
        speak_output = "Energy Generated Today is "+str(energyTday)+"KWh"
        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )


class MyNameIsIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return is_intent_name("MyNameIsIntent")(handler_input)
    
    def handle(self,handler_input):
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        persistent_attributes = handler_input.attributes_manager.persistent_attributes
        
        user_name = handler_input.request_envelope.request.intent.slots["UserNameSlot"].value
        persistent_attributes["user_name"] = user_name
        
        # Write user's name to the DB.
        handler_input.attributes_manager.save_persistent_attributes()
        
        speech_output = random.choice(language_prompts["NAME_SAVED"]).format(user_name)
        reprompt = random.choice(language_prompts["NAME_SAVED_REPROMPT"])
        
        return(
            handler_input.response_builder
                .speak(speech_output)
                .ask(reprompt)
                .response
            )

class WhatsMyNameIntentHandler(AbstractRequestHandler):
    
    def can_handle(self, handler_input):
        return is_intent_name("WhatsMyNameIntent")(handler_input)
    
    def handle(self, handler_input):
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        persistent_attributes = handler_input.attributes_manager.persistent_attributes
        
        try:
            # Read user's name from the DB.
            user_name = persistent_attributes['user_name']
            
            speech_output = random.choice(language_prompts["TELL_NAME"]).format(user_name)
            reprompt = random.choice(language_prompts["TELL_NAME_REPROMPT"])
        except:
            speech_output = random.choice(language_prompts["NO_NAME"])
            reprompt = random.choice(language_prompts["NO_NAME_REPROMPT"])        
        
        return (
            handler_input.response_builder
                .speak(speech_output)
                .ask(reprompt)
                .response
            )

class UpdateNameIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return is_intent_name("UpdateNameIntent")(handler_input)
    
    def handle(self,handler_input):
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        persistent_attributes = handler_input.attributes_manager.persistent_attributes
        
        user_name = handler_input.request_envelope.request.intent.slots["NewNameSlot"].value
        # Update user's name
        persistent_attributes["user_name"] = user_name
        handler_input.attributes_manager.save_persistent_attributes()
        
        speech_output = random.choice(language_prompts["NAME_UPDATED"]).format(user_name)
        reprompt = random.choice(language_prompts["NAME_UPDATED_REPROMPT"])
        
        return(
            handler_input.response_builder
                .speak(speech_output)
                .ask(reprompt)
                .response
            )

class DeleteNameIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return is_intent_name("DeleteNameIntent")(handler_input)
    def handle(self,handler_input):
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        
        # Delete all attributes from the DB
        handler_input.attributes_manager.delete_persistent_attributes()
        
        speech_output = random.choice(language_prompts["NAME_DELETED"])
        reprompt = random.choice(language_prompts["NAME_DELETED_REPROMPT"])
        
        return(
            handler_input.response_builder
                .speak(speech_output)
                .ask(reprompt)
                .response
            )

class RepeatIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return is_intent_name("AMAZON.RepeatIntent")(handler_input)
    
    def handle(self, handler_input):
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        session_attributes = handler_input.attributes_manager.session_attributes
        
        repeat_speech_output = session_attributes["repeat_speech_output"]
        repeat_reprompt = session_attributes["repeat_reprompt"]
        
        speech_output = random.choice(language_prompts["REPEAT"]).format(repeat_speech_output)
        reprompt = random.choice(language_prompts["REPEAT_REPROMPT"]).format(repeat_reprompt)
        
        return (
            handler_input.response_builder
                .speak(speech_output)
                .ask(reprompt)
                .response
            )

class CancelOrStopIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return (is_intent_name("AMAZON.CancelIntent")(handler_input) or
                is_intent_name("AMAZON.StopIntent")(handler_input))
    
    def handle(self, handler_input):
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        speech_output = random.choice(language_prompts["CANCEL_STOP_RESPONSE"])
        reprompt = random.choice(language_prompts["REPEAT_REPROMPT"]).format(repeat_reprompt)
        return (
            handler_input.response_builder
                .speak(speech_output)
                .ask(reprompt)
                .response
            )

class CancelOrStopIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return (is_intent_name("AMAZON.CancelIntent")(handler_input) or
                is_intent_name("AMAZON.StopIntent")(handler_input))
    
    def handle(self, handler_input):
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        speech_output = random.choice(language_prompts["CANCEL_STOP_RESPONSE"])
        
        return (
            handler_input.response_builder
                .speak(speech_output)
                .set_should_end_session(True)
                .response
            )

class HelpIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return is_intent_name("AMAZON.HelpIntent")(handler_input)
    
    def handle(self, handler_input):
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        speech_output = random.choice(language_prompts["HELP"])
        reprompt = random.choice(language_prompts["HELP_REPROMPT"])
        
        return (
            handler_input.response_builder
                .speak(speech_output)
                .ask(reprompt)
                .response
            )

# This handler handles utterances that can't be matched to any other intent handler.
class FallbackIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return is_intent_name("AMAZON.FallbackIntent")(handler_input)
    
    def handle(self, handler_input):
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        speech_output = random.choice(language_prompts["FALLBACK"])
        reprompt = random.choice(language_prompts["FALLBACK_REPROMPT"])
        
        return (
            handler_input.response_builder
                .speak(speech_output)
                .ask(reprompt)
                .response
        )
class SessionEndedRequesthandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return is_request_type("SessionEndedRequest")(handler_input)
    
    def handle(self, handler_input):
        logger.info("Session ended with the reason: {}".format(handler_input.request_envelope.request.reason))
        return handler_input.response_builder.response
class CatchAllExceptionHandler(AbstractExceptionHandler):
    
    def can_handle(self, handler_input, exception):
        return True
    
    def handle(self, handler_input, exception):
        logger.error(exception, exc_info=True)
        
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        
        speech_output = language_prompts["ERROR"]
        reprompt = language_prompts["ERROR_REPROMPT"]
        
        return (
            handler_input.response_builder
                .speak(speech_output)
                .ask(reprompt)
                .response
            )

class RequestLogger(AbstractRequestInterceptor):

    def process(self, handler_input):
        logger.debug("Alexa Request: {}".format(
            handler_input.request_envelope.request))

# This interceptor logs each response our endpoint sends back to Alexa.
class ResponseLogger(AbstractResponseInterceptor):

    def process(self, handler_input, response):
        logger.debug("Alexa Response: {}".format(response))

# This interceptor is used for supporting different languages and locales. It detects the users locale,
# loads the corresponding language prompts and sends them as a request attribute object to the handler functions.
class LocalizationInterceptor(AbstractRequestInterceptor):

    def process(self, handler_input):
        locale = handler_input.request_envelope.request.locale
        logger.info("Locale is {}".format(locale))
        
        try:
            with open("languages/"+str(locale)+".json") as language_data:
                language_prompts = json.load(language_data)
        except:
            with open("languages/"+ str(locale[:2]) +".json") as language_data:
                language_prompts = json.load(language_data)
        
        handler_input.attributes_manager.request_attributes["_"] = language_prompts

# This interceptor fetches the speech_output and reprompt messages from the response and pass them as
# session attributes to be used by the repeat intent handler later on.
class RepeatInterceptor(AbstractResponseInterceptor):

    def process(self, handler_input, response):
        session_attributes = handler_input.attributes_manager.session_attributes
        session_attributes["repeat_speech_output"] = response.output_speech.ssml.replace("<speak>","").replace("</speak>","")
        try:
            session_attributes["repeat_reprompt"] = response.reprompt.output_speech.ssml.replace("<speak>","").replace("</speak>","")
        except:
            session_attributes["repeat_reprompt"] = response.output_speech.ssml.replace("<speak>","").replace("</speak>","")


# Skill Builder
# Define a skill builder instance and add all the request handlers,
# exception handlers and interceptors to it.

sb = CustomSkillBuilder(persistence_adapter = dynamodb_adapter)
sb.add_request_handler(LaunchRequestHandler())

sb.add_request_handler(EnergyGeneratedTodayHandler())
sb.add_request_handler(CheckFaultyInverterHandler())
sb.add_request_handler(RetrieveLatestInstanceHandler())

sb.add_request_handler(MyNameIsIntentHandler())
sb.add_request_handler(WhatsMyNameIntentHandler())
sb.add_request_handler(UpdateNameIntentHandler())
sb.add_request_handler(DeleteNameIntentHandler())
sb.add_request_handler(RepeatIntentHandler())
sb.add_request_handler(CancelOrStopIntentHandler())
sb.add_request_handler(HelpIntentHandler())
sb.add_request_handler(FallbackIntentHandler())
sb.add_request_handler(SessionEndedRequesthandler())

sb.add_exception_handler(CatchAllExceptionHandler())

sb.add_global_response_interceptor(RepeatInterceptor())
sb.add_global_request_interceptor(LocalizationInterceptor())
sb.add_global_request_interceptor(RequestLogger())
sb.add_global_response_interceptor(ResponseLogger())

lambda_handler = sb.lambda_handler()

    





